import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;

public class Main {
    public static int ImprimirMenu() {

        Scanner ler = new Scanner(System.in);
        System.out.println("--------------------------------");
        System.out.println(" 1 - Preencher Coordenadas ");
        System.out.println(" 2 - Imprimir Coordenadas   ");
        System.out.println(" 3 - Distancia entre dois pontos ");
        System.out.println(" 4 - Pontos são colineares?   ");
        System.out.println(" 5 - Forma um triangulo ? Se sim , calcular área do triangulo ");
        System.out.println(" 0 - Sair ");
        System.out.println("--------------------------------");
        System.out.println("Escolha uma opcao: ");
        return ler.nextInt();

    }

    public static void main(String[] args) {

        Scanner ler = new Scanner(System.in);
        List<Ponto> listaPontos;
        listaPontos = new ArrayList<Ponto>(); //Arra-list para pontos

        int opcao = ImprimirMenu();

        do {
            opcao = ImprimirMenu();

            if (opcao == 1) {
                //prrencher coordenadas
                Ponto p1 = new Ponto();
                System.out.println(" Informe os valores de X e Y ");
                p1.PreencherPonto();
                listaPontos.add(p1);


            } else if (opcao == 2) {
                //imprimir coordenadas
                for (int i = 0; i < listaPontos.size() - 1; i++) {
                    listaPontos.get(i).ImprimirCoordenadas();
                }

            } else if (opcao == 3) {
                //calcular distancia entre dois pontos

                if (listaPontos.size() >= 2) { //verificar se a lista tem no minimo dois pontos
                    for (int i = 0; i < listaPontos.size() - 1; i++) {
                        listaPontos.get(i).CalcularDistanciaPontos(listaPontos.get(i + 1));
                    }

                } else {
                    System.out.println(" A lista não tem pontos suficientes (o minimo é 2)! ");
                }


            } else if (opcao == 4) {
                //verificar se sao colineares

                double determinante;

                if (listaPontos.size() >= 3) {
                    System.out.println("A lista possui 3 ou mais pontos, logo o determinante é:");

                    determinante = listaPontos.get(0).CalcularDeterminante( //calcular o det dos 3 pontos
                            listaPontos.get(0),
                            listaPontos.get(1),
                            listaPontos.get(2)
                    );

                    System.out.println("Determinante: " + determinante);

                    if (determinante == 0) {
                        System.out.println("Os pontos são colineares");
                    } else {
                        System.out.println("Os pontos não são colineares");
                    }
                } else {
                    System.out.println("A lista não possui 3 pontos, logo não é possível calcular o determinante.");
                }

            } else if (opcao == 5) {
                //calcular area triangulo
                double area;
                if (listaPontos.size() >= 3) {
                    System.out.println("A lista possui 3 ou mais pontos, logo a área do triangulo é:");
                    area = listaPontos.get(0).CalcularAreaTriangulo(listaPontos.get(0), listaPontos.get(1), listaPontos.get(2));
                    System.out.println(" A área do triangulo é: " + area);
                } else {
                    System.out.println(" A lista não possui 3 ou mais pontos, logo não é um triangulo e não é possivel calcular a sua área ");
                }
            }
        } while (opcao != 0) ;


        }
    }
