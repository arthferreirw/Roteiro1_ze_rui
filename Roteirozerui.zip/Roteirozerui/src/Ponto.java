import java.util.Scanner;


public class Ponto {
    private int x; //ponto x
    private int y; //ponto y

    public Ponto() {
        this.x = 0;
        this.y = 0;

    }

    public Ponto(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;

    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void PreencherPonto() {

        Scanner ler = new Scanner(System.in);

        System.out.println(" Defina um valor para o ponto X: ");
        this.x = ler.nextInt();

        System.out.println(" Defina um valor para o ponto Y: ");
        this.y = ler.nextInt();
    }

    public void ImprimirCoordenadas() {

        System.out.printf("(%d,%d)\n", this.x, this.y);

    }

    public void CalcularDistanciaPontos(Ponto outro) {
        double distancia = Math.sqrt(Math.pow(outro.x - this.x, 2) + Math.pow(outro.y - this.y, 2));
        System.out.printf("Distância entre os pontos (%d, %d) e (%d, %d): %.2f\n",
                this.x, this.y, outro.x, outro.y, distancia);

    }
    public double CalcularDeterminante(Ponto p1 , Ponto p2 , Ponto p3){
        double l1 = p1.getX() * p2.getY() + p2.getX() * p3.getY() + p3.getX() * p1.getY(); //Linha 1 do determinante
        double l2 = p3.getX() * p2.getY() + p1.getX() * p3.getY() + p2.getX() * p1.getY(); //linha 2 determinante

        double det = (l1-l2);

        return det;
    }
    public double CalcularAreaTriangulo (Ponto p1 , Ponto p2 , Ponto p3){
        double det = CalcularDeterminante( p1 ,  p2 ,  p3);
        double areaTriangulo = Math.abs(det/2.0); //valor absoluto para a área não ser negativa

        return areaTriangulo;

    }
}

